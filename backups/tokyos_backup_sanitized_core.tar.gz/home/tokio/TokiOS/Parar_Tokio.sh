#!/bin/bash
# Parar_Tokio.sh
# Finaliza todos os processos levantados pelo Servidor_Tokio_Producao.sh

LOG_DIR="/home/tokio/TokiOS/logs"

echo "====================================="
echo "Parando TokyOS..."
echo "====================================="

# Lê todos os arquivos .pid e mata os processos
for pid_file in ${LOG_DIR}/*.pid; do
    if [ -f "$pid_file" ]; then
        PID=$(cat "$pid_file")
        if ps -p $PID > /dev/null; then
            echo "Finalizando processo $PID ($(basename $pid_file .pid))..."
            kill -9 $PID
        else
            echo "Processo $PID ($(basename $pid_file .pid)) já estava parado."
        fi
        rm -f "$pid_file"
    fi
done

# Fallback: garante que tudo foi limpo
pkill -f "npm start"
pkill -f "npm run dev"
pkill -f "streamlit run"

echo "====================================="
echo "🛑 Sistema Parado com Sucesso."
echo "====================================="
