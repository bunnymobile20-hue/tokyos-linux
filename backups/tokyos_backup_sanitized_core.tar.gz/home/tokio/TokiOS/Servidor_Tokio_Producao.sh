#!/bin/bash
# Servidor_Tokio_Producao.sh
# Script para iniciar todos os serviços do TokyOS em modo 24/7 (background)

PROJECT_ROOT="/home/tokio/TokiOS"
LOG_DIR="${PROJECT_ROOT}/logs"
BACKUP_DIR="${PROJECT_ROOT}/backups"

mkdir -p "$LOG_DIR"
mkdir -p "$BACKUP_DIR"

echo "====================================="
echo "Iniciando TokyOS - Servidor 24/7"
echo "====================================="

# Função para iniciar um processo em background com nohup
start_service() {
    local NAME=$1
    local CMD=$2
    local LOG=$3
    
    echo "Iniciando $NAME..."
    nohup bash -c "$CMD" > "$LOG" 2>&1 &
    local PID=$!
    echo "$PID" > "${LOG_DIR}/${NAME}.pid"
    echo "$NAME rodando no PID $PID"
}

# 1. Parar serviços antigos (se existirem)
if [ -f "${PROJECT_ROOT}/Parar_Tokio.sh" ]; then
    bash "${PROJECT_ROOT}/Parar_Tokio.sh"
fi

# 2. Iniciar Backend (Node.js) - Usa porta 3001
start_service "Backend_Tokio" "cd ${PROJECT_ROOT}/backend && npm start" "${LOG_DIR}/backend.log"

# 3. Iniciar Frontend (React) - Usa porta 5173 / ou build servida estática
start_service "Frontend_Tokio" "cd ${PROJECT_ROOT}/frontend && CI=true npm run dev" "${LOG_DIR}/frontend.log"

# 4. Iniciar Dashboard Bunny Dreams (Streamlit) - Porta 8501
start_service "Streamlit_ERP" "cd ${PROJECT_ROOT}/dashboard && ./venv/bin/streamlit run app.py --server.port 8501 --server.headless true" "${LOG_DIR}/streamlit_erp.log"

# 5. Iniciar Dashboard AutoTeste (Streamlit) - Porta 8502
start_service "Streamlit_Health" "cd ${PROJECT_ROOT}/tools/health_check && ../../dashboard/venv/bin/streamlit run app.py --server.port 8502 --server.headless true" "${LOG_DIR}/streamlit_health.log"

# 6. Iniciar Motor RPA WinGestor (WebSocket Browser-Use) - Porta 8765
start_service "Motor_RPA_Wingestor" "cd ${PROJECT_ROOT}/browser_agent && ./venv/bin/python server.py" "${LOG_DIR}/motor_rpa_wingestor.log"

echo "====================================="
echo "✅ Todos os serviços foram iniciados em background!"
echo "Use 'bash Parar_Tokio.sh' para desligar tudo."
echo "Logs disponíveis em: $LOG_DIR"
echo "====================================="
