#!/bin/bash
# tokyo_backup.sh
# Realiza backup dos bancos de dados e configurações críticas

PROJECT_ROOT="/home/tokio/TokiOS"
BACKUP_DIR="${PROJECT_ROOT}/backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="${BACKUP_DIR}/tokyo_backup_${TIMESTAMP}.tar.gz"

echo "====================================="
echo "Iniciando Backup - TokyOS"
echo "====================================="

mkdir -p "$BACKUP_DIR"

# Coletar arquivos de banco de dados
echo "Copiando bancos de dados..."
DB_TEMP_DIR="/tmp/tokyo_backup_tmp_${TIMESTAMP}"
mkdir -p "$DB_TEMP_DIR"
cp ${PROJECT_ROOT}/data/database/*.db "$DB_TEMP_DIR/" 2>/dev/null

# Coletar env vars
echo "Copiando configurações seguras..."
cp ~/.clawos/.env "$DB_TEMP_DIR/env_backup.txt" 2>/dev/null

# Compactar
echo "Compactando arquivos em $BACKUP_FILE..."
tar -czf "$BACKUP_FILE" -C "/tmp" "tokyo_backup_tmp_${TIMESTAMP}"

# Limpeza
rm -rf "$DB_TEMP_DIR"

echo "====================================="
echo "✅ Backup concluído: $BACKUP_FILE"
echo "====================================="
