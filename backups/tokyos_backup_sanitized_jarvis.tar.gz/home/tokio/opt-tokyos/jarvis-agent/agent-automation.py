from dotenv import load_dotenv
from livekit import agents
from livekit.agents import AgentSession, Agent, RoomInputOptions, ChatContext, llm
from livekit.plugins import noise_cancellation, google
from prompts import AGENT_INSTRUCTION, SESSION_INSTRUCTION
from mem0 import AsyncMemoryClient
import logging
import os
import asyncio
import webbrowser
import subprocess
import shutil
from datetime import datetime
from pathlib import Path
import websockets
from urllib.parse import quote_plus
import urllib.request as _urllib

try:
    import yt_dlp
    YT_DLP_DISPONIVEL = True
except ImportError:
    YT_DLP_DISPONIVEL = False

try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_DISPONIVEL = True
except ImportError:
    PLAYWRIGHT_DISPONIVEL = False

from automacao_jarvis import JarvisControl

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────
# CHROME + CDP (Linux)
# ─────────────────────────────────────────

def _get_chrome_path():
    candidates = [
        "google-chrome", "google-chrome-stable", "chromium", "chromium-browser"
    ]
    for name in candidates:
        path = shutil.which(name)
        if path:
            return path
    return None

CHROME_PATH = _get_chrome_path()
CDP_URL = "http://localhost:9222"
MEMORIA_DIR = Path(os.environ.get("TOKIOS_DIR", "/home/tokio/TokiOS")) / "_memoria"
SKILLS_DIR = Path(os.environ.get("TOKIOS_DIR", "/home/tokio/TokiOS")) / "_skills"


class SkillsManager:
    """Gerenciamento de skills auto-geradas para navegação web."""

    SKILL_FILE = "SKILL.md"

    def _skill_path(self, name: str) -> Path:
        slug = name.lower().strip().replace(" ", "-")[:48]
        return SKILLS_DIR / slug / self.SKILL_FILE

    def search(self, tarefa: str) -> list[dict]:
        """Busca skills relevantes para uma tarefa por correspondência de palavras-chave."""
        if not SKILLS_DIR.exists():
            return []
        palavras = set(tarefa.lower().split())
        results = []
        for skill_dir in sorted(SKILLS_DIR.iterdir()):
            skill_file = skill_dir / self.SKILL_FILE
            if not skill_file.exists():
                continue
            try:
                front, body = self._parse(skill_file)
                nome = front.get("name", "")
                desc = front.get("description", "")
                tags = " ".join(front.get("tags", []))
                texto_busca = f"{nome} {desc} {tags}".lower()
                score = sum(1 for p in palavras if p in texto_busca)
                if score > 0:
                    results.append({"name": nome, "description": desc, "score": score, "content": body, "tags": front.get("tags", [])})
            except Exception:
                continue
        results.sort(key=lambda r: r["score"], reverse=True)
        return results[:3]

    def create(self, name: str, description: str, tags: list[str], content: str, created_by: str = "agent"):
        """Cria uma skill como SKILL.md com frontmatter."""
        slug = name.lower().strip().replace(" ", "-")[:48]
        skill_dir = SKILLS_DIR / slug
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file = skill_dir / self.SKILL_FILE
        agora = datetime.now().isoformat()
        tags_yaml = "\n".join(f"  - {t}" for t in tags)
        conteudo = f"""---
name: {name}
description: {description}
created_at: {agora}
created_by: {created_by}
tags:
{tags_yaml}
---

# {name}

{description}

{content}
"""
        skill_file.write_text(conteudo.strip() + "\n", encoding="utf-8")
        return str(skill_file)

    def list_all(self) -> list[dict]:
        """Lista todas as skills instaladas."""
        if not SKILLS_DIR.exists():
            return []
        results = []
        for skill_dir in sorted(SKILLS_DIR.iterdir()):
            skill_file = skill_dir / self.SKILL_FILE
            if not skill_file.exists():
                continue
            try:
                front, body = self._parse(skill_file)
                results.append({"name": front.get("name", skill_dir.name), "description": front.get("description", ""), "tags": front.get("tags", []), "created_by": front.get("created_by", "unknown")})
            except Exception:
                continue
        return results

    def _parse(self, path: Path) -> tuple[dict, str]:
        text = path.read_text(encoding="utf-8")
        if not text.startswith("---"):
            return {}, text
        parts = text.split("---", 2)
        if len(parts) < 3:
            return {}, text
        front = {}
        current_key = None
        for line in parts[1].strip().split("\n"):
            if line.startswith("  - "):
                val = line.strip("- ").strip()
                if current_key and isinstance(front.get(current_key), list):
                    front[current_key].append(val)
                continue
            if ":" in line:
                key, val = line.split(":", 1)
                key = key.strip()
                val = val.strip()
                current_key = key
                if val == "" or val.startswith("#"):
                    front[key] = []
                else:
                    front[key] = val
        return front, parts[2].strip()

    def delete(self, name: str) -> bool:
        slug = name.lower().strip().replace(" ", "-")[:48]
        skill_dir = SKILLS_DIR / slug
        if skill_dir.exists():
            import shutil
            shutil.rmtree(skill_dir)
            return True
        return False

def _cdp_disponivel() -> bool:
    try:
        with _urllib.urlopen(f"{CDP_URL}/json/version", timeout=1) as r:
            return r.status == 200
    except:
        return False

async def _abrir_chrome_com_cdp(url: str = "about:blank"):
    if not CHROME_PATH:
        webbrowser.open(url)
        return False
    if _cdp_disponivel():
        try:
            async with async_playwright() as p:
                browser = await p.chromium.connect_over_cdp(CDP_URL)
                page = await browser.contexts[0].new_page()
                await page.goto(url)
                await browser.disconnect()
            return True
        except:
            pass
    subprocess.Popen([CHROME_PATH, f"--remote-debugging-port=9222", url],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    await asyncio.sleep(2.5)
    return _cdp_disponivel()


# ─────────────────────────────────────────
# AGENTE
# ─────────────────────────────────────────

class Assistant(Agent, llm.ToolContext):
    def __init__(self, chat_ctx: ChatContext = None):
        llm.ToolContext.__init__(self, [])
        super().__init__(
            instructions=AGENT_INSTRUCTION,
            llm=google.beta.realtime.RealtimeModel(
                voice="Charon",
                temperature=0.6,
            ),
            chat_ctx=chat_ctx,
        )
        self.jarvis_control = JarvisControl()

    # ────────────────────────────────
    # MÍDIA E WEB
    # ────────────────────────────────

    @agents.function_tool
    async def pesquisar_na_web(self, consulta: str, tipo: str = "google"):
        """
        Faz uma busca ou abre o YouTube.
        tipo = 'google' → busca no Google
        tipo = 'youtube' → abre a busca no YouTube (não inicia um vídeo automaticamente)
        tipo = 'url' → abre a URL diretamente
        """
        try:
            if tipo.lower() == "youtube":
                # Abre a BUSCA no YouTube, não um vídeo aleatório
                url = f"https://www.youtube.com/results?search_query={quote_plus(consulta)}"
                await _abrir_chrome_com_cdp(url)
                return f"Abrindo busca do YouTube por '{consulta}'."

            elif tipo.lower() == "url":
                await _abrir_chrome_com_cdp(consulta)
                return f"Abrindo: {consulta}"

            else: # google (padrão)
                url = f"https://www.google.com/search?q={quote_plus(consulta)}"
                await _abrir_chrome_com_cdp(url)
                return f"Pesquisando '{consulta}' no Google."
        except Exception as e:
            return f"Erro na pesquisa: {e}"

    @agents.function_tool
    async def pausar_retomar_youtube(self):
        """Pausa ou retoma o vídeo do YouTube que estiver tocando no Chrome."""
        try:
            import pyautogui
            pyautogui.press("k")
            return "Play/Pause alternado no YouTube via K key ✓"
        except Exception as e:
            return f"Erro no controle de mídia: {e}"

    @agents.function_tool
    async def fechar_programa(self, programa: str):
        """Fecha um programa pelo nome (ex: 'chrome', 'notepad', 'spotify')."""
        import signal
        res = subprocess.run(["pkill", "-f", programa],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if res.returncode == 0:
            return f"Programa '{programa}' fechado com sucesso."
        return f"Não foi possível fechar '{programa}'. Verifique o nome do processo."

    @agents.function_tool
    async def abrir_programa(self, comando: str):
        """Abre um programa ou executável pelo nome (ex: 'gedit', 'firefox')."""
        try:
            subprocess.Popen(comando.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"'{comando}' aberto."
        except Exception as e:
            return f"Erro ao abrir '{comando}': {e}"

    # ────────────────────────────────
    # ARQUIVOS E PASTAS
    # ────────────────────────────────

    @agents.function_tool
    async def criar_pasta(self, caminho: str):
        """
        Cria uma pasta. Exemplos de comandos válidos:
        - 'Projetos' → cria na Área de Trabalho
        - 'Projetos/Python' → cria subpasta na Área de Trabalho
        - 'Desktop/Projetos' → equivale a Área de Trabalho
        NÃO inclua 'C:/' ou caminhos absolutos, apenas o nome da pasta.
        """
        return self.jarvis_control.cria_pasta(caminho)

    @agents.function_tool
    async def deletar_item(self, caminho: str):
        """Deleta um arquivo ou pasta pelo nome ou caminho."""
        return self.jarvis_control.deletar_arquivo(caminho)

    @agents.function_tool
    async def limpar_diretorio(self, caminho: str):
        """Remove todo o conteúdo de uma pasta, sem deletar a pasta em si."""
        return self.jarvis_control.limpar_diretorio(caminho)

    @agents.function_tool
    async def mover_item(self, origem: str, destino: str):
        """Move um arquivo ou pasta de origem para destino."""
        return self.jarvis_control.mover_item(origem, destino)

    @agents.function_tool
    async def copiar_item(self, origem: str, destino: str):
        """Copia um arquivo ou pasta para um novo local."""
        return self.jarvis_control.copiar_item(origem, destino)

    @agents.function_tool
    async def renomear_item(self, caminho: str, novo_nome: str):
        """Renomeia um arquivo ou pasta."""
        return self.jarvis_control.renomear_item(caminho, novo_nome)

    @agents.function_tool
    async def organizar_pasta(self, caminho: str):
        """Organiza os arquivos de uma pasta por tipo (Imagens, Documentos, etc.)."""
        return self.jarvis_control.organizar_pasta(caminho)

    @agents.function_tool
    async def compactar_pasta(self, caminho: str):
        """Compacta uma pasta em um arquivo .zip."""
        return self.jarvis_control.compactar_pasta(caminho)

    @agents.function_tool
    async def abrir_pasta(self, nome_pasta: str):
        """Abre uma pasta no Explorador de Arquivos pelo nome."""
        return self.jarvis_control.abrir_pasta(nome_pasta)

    @agents.function_tool
    async def buscar_e_abrir_arquivo(self, nome_arquivo: str):
        """Busca um arquivo por nome e o abre automaticamente."""
        return self.jarvis_control.buscar_e_abrir_arquivo(nome_arquivo)

    # ────────────────────────────────
    # SISTEMA
    # ────────────────────────────────

    @agents.function_tool
    async def controle_volume(self, nivel: int):
        """Ajusta o volume do sistema de 0 a 100."""
        return self.jarvis_control.controle_volume(nivel)

    @agents.function_tool
    async def controle_brilho(self, nivel: int):
        """Ajusta o brilho da tela de 0 a 100."""
        return self.jarvis_control.controle_brilho(nivel)

    @agents.function_tool
    async def energia_pc(self, acao: str):
        """Controla a energia do PC. Ações: 'desligar', 'reiniciar', 'bloquear'."""
        return self.jarvis_control.energia_pc(acao)

    @agents.function_tool
    async def abrir_aplicativo(self, nome_app: str):
        """Abre aplicativos conhecidos pelo nome (ex: 'spotify', 'vscode', 'calculadora')."""
        return self.jarvis_control.abrir_aplicativo(nome_app)

    @agents.function_tool
    async def abrir_app_clawos(self, nome_app: str):
        """
        Abre um aplicativo do sistema ClawOS/TokyOS.
        Nomes válidos: 'dashboard' (Status do Sistema), 'monitor' (Monitoramento),
        'files' (Arquivos/FileBrowser), 'downloads' (Downloads), 'notes' (Notas).
        Exemplo: 'abrir notas do sistema' → abrir_app_clawos('notes')
        """
        import base64
        import json
        import urllib.request
        try:
            app_map = {
                "dashboard": "dashboard", "status": "dashboard",
                "monitor": "monitor", "monitoramento": "monitor",
                "files": "files", "arquivos": "files",
                "downloads": "downloads",
                "notes": "notes", "notas": "notes",
            }
            app_id = app_map.get(nome_app.lower().replace("ó","o").replace("ã","a"))
            if not app_id:
                return f"App '{nome_app}' não reconhecido. Apps disponíveis: dashboard, monitor, files, downloads, notes"
            clawos_pass = os.environ.get("CLAWOS_PASSWORD", "32215820")
            auth = base64.b64encode(f"clawos:{clawos_pass}".encode()).decode()
            body = json.dumps({"app_id": app_id}).encode()
            req = urllib.request.Request(
                "http://127.0.0.1:3001/api/system/apps/launch",
                data=body,
                headers={"Content-Type": "application/json", "Authorization": f"Basic {auth}"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=3) as r:
                resp = r.read().decode()
            return f"Aplicativo '{nome_app}' aberto no ClawOS."
        except Exception as e:
            return f"Erro ao abrir app: {e}"

    def _api_call(self, method: str, path: str, body: dict = None) -> dict:
        import base64, json, urllib.request
        clawos_pass = os.environ.get("CLAWOS_PASSWORD", "32215820")
        auth = base64.b64encode(f"clawos:{clawos_pass}".encode()).decode()
        url = f"http://127.0.0.1:3001{path}"
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", f"Basic {auth}")
        with urllib.request.urlopen(req, timeout=5) as r:
            return json.loads(r.read().decode())

    @agents.function_tool
    async def criar_nota(self, titulo: str, conteudo: str = ""):
        """
        Cria uma nova nota no sistema ClawOS.
        Use quando o usuário pedir para criar uma nota, anotar algo, fazer uma lista.
        Exemplo: 'criar nota com titulo Compras e conteudo Leite, ovos, pao'
        """
        try:
            resp = self._api_call("POST", "/api/system/notes", {"title": titulo, "content": conteudo})
            if resp.get("success"):
                return f"Nota '{titulo}' criada com sucesso."
            return f"Erro ao criar nota: {resp.get('error', 'desconhecido')}"
        except Exception as e:
            return f"Erro ao criar nota: {e}"

    @agents.function_tool
    async def listar_notas(self):
        """
        Lista todas as notas do sistema ClawOS.
        Use quando o usuário pedir para ver as notas, listar anotações, ou perguntar o que está anotado.
        """
        try:
            resp = self._api_call("GET", "/api/system/notes")
            if resp.get("success"):
                notas = resp.get("data", [])
                if not notas:
                    return "Nenhuma nota encontrada."
                lista = "\n".join([f"- {n.get('title', 'sem titulo')}" for n in notas[:20]])
                return f"Notas encontradas:\n{lista}"
            return f"Erro ao listar notas: {resp.get('error', 'desconhecido')}"
        except Exception as e:
            return f"Erro ao listar notas: {e}"

    @agents.function_tool
    async def navegar_web(self, tarefa: str):
        """
        Executa uma tarefa de navegacao web automatica usando Browser Use + IA local.
        O modelo IA abre o navegador, navega por sites, clica, preenche formularios e extrai informacoes.
        Use para: 'entra no site X e faz Y', 'acha o preco de Z', 'baixa a fatura do site W'.
        Exemplo: 'navegar_web: entra no google e pesquisa por preco do playstation 5'
        """
        import json
        skills_mgr = SkillsManager()
        relevantes = skills_mgr.search(tarefa)
        instrucao_final = tarefa
        if relevantes:
            ctx_skills = "\n\n".join([f"### {s['name']}\n{s['description']}\n\n{s['content']}" for s in relevantes])
            instrucao_final = f"{tarefa}\n\n## Skills relevantes encontradas\nUse estas skills como guia se aplicavel:\n\n{ctx_skills}"
        try:
            async with websockets.connect("ws://127.0.0.1:8765") as ws:
                await ws.send(json.dumps({"type": "browser_task", "instruction": instrucao_final}))
                result = await ws.recv()
                while True:
                    data = json.loads(result)
                    if data.get("type") == "result":
                        return f"Navegacao concluida: {data['data']}"
                    if data.get("type") == "error":
                        return f"Erro na navegacao: {data['error']}"
                    result = await ws.recv()
        except Exception as e:
            return f"Erro ao conectar no Browser Agent: {e}"

    @agents.function_tool
    async def criar_skill(self, nome: str, descricao: str, tags: str, conteudo: str):
        """
        Cria uma skill reutilizavel de automacao web.
        Skills sao templates que o agente pode reusar em tarefas similares no futuro.
        Use quando uma automacao deu certo e pode ser padronizada.
        Exemplo: 'criar skill para buscar preco no Mercado Livre'
        tags: lista separada por virgula (ex: 'mercadolivre, precos, compras')
        conteudo: instrucoes passo a passo para executar a automacao
        """
        try:
            skills_mgr = SkillsManager()
            lista_tags = [t.strip() for t in tags.split(",") if t.strip()]
            path = skills_mgr.create(nome, descricao, lista_tags, conteudo)
            return f"Skill '{nome}' criada em {path}"
        except Exception as e:
            return f"Erro ao criar skill: {e}"

    @agents.function_tool
    async def listar_skills(self):
        """
        Lista todas as skills de automacao web disponiveis.
        Use para ver o que o sistema ja aprendeu automaticamente.
        """
        try:
            skills_mgr = SkillsManager()
            skills = skills_mgr.list_all()
            if not skills:
                return "Nenhuma skill cadastrada ainda."
            linhas = []
            for s in skills:
                tags = ", ".join(s.get("tags", []))
                tags_str = f" [{tags}]" if tags else ""
                origem = "🤖 auto" if s.get("created_by") == "agent" else "👤 manual"
                linhas.append(f"- **{s['name']}**{tags_str} ({origem}): {s['description']}")
            return f"Skills disponiveis:\n" + "\n".join(linhas)
        except Exception as e:
            return f"Erro ao listar skills: {e}"

    @agents.function_tool
    async def registrar_memorial(self, titulo: str, descricao: str):
        """
        Registra um memorial de decisao importante para memoria longa do sistema.
        Use quando o usuario toma uma decisao relevante, define metas, ou apos acoes significativas.
        Exemplo: 'registrar que decidiu meta de 150k para Teresina'
        """
        try:
            MEMORIA_DIR.mkdir(parents=True, exist_ok=True)
            agora = datetime.now()
            data_str = agora.strftime("%Y-%m-%d")
            hora_str = agora.strftime("%H:%M")
            slug = titulo.lower().replace(" ", "-")[:40]
            filename = f"{data_str}-{slug}.md"
            filepath = MEMORIA_DIR / filename

            conteudo = f"""---
data: {data_str}
hora: {hora_str}
titulo: {titulo}
---

## {titulo}

**Data:** {data_str}
**Hora:** {hora_str}

{descricao}
"""
            filepath.write_text(conteudo.strip() + "\n", encoding="utf-8")
            return f"Memorial '{titulo}' registrado em _memoria/{filename}"
        except Exception as e:
            return f"Erro ao registrar memorial: {e}"


# ─────────────────────────────────────────
# ENTRYPOINT
# ─────────────────────────────────────────

async def entrypoint(ctx: agents.JobContext):

    user_id = "PedroLucas"
    mem0_client = None
    if os.environ.get("MEM0_API_KEY"):
        try:
            mem0_client = AsyncMemoryClient()
        except Exception as e:
            logger.warning(f"[Mem0] Não foi possível inicializar: {e}")
            mem0_client = None

    await ctx.connect()

    session = AgentSession()
    agent = Assistant(chat_ctx=ChatContext())

    await session.start(
        room=ctx.room,
        agent=agent,
        room_input_options=RoomInputOptions(
            video_enabled=True,
            noise_cancellation=noise_cancellation.BVC(),
        ),
    )

    # ── Carregar Memória de Longo Prazo (opcional) ──
    if mem0_client:
        try:
            logger.info(f"[Mem0] Carregando memórias para '{user_id}'...")
            response = await mem0_client.search(
                query="histórico, preferências e informações pessoais do usuário",
                filters={"user_id": user_id},
                limit=20,
            )
            if isinstance(response, dict):
                results = response.get("results", [])
            elif isinstance(response, list):
                results = response
            else:
                results = []

            logger.info(f"[Mem0] {len(results)} memórias encontradas.")

            if results:
                memorias = []
                for r in results:
                    texto = None
                    if isinstance(r, dict):
                        texto = r.get("memory") or r.get("text") or r.get("content")
                    if texto:
                        memorias.append(f"- {texto}")

                if memorias:
                    bloco = "\n".join(memorias)
                    ctx_copia = agent.chat_ctx.copy()
                    ctx_copia.add_message(
                        role="assistant",
                        content=f"[Memória carregada — informações sobre o usuário]\n{bloco}"
                    )
                    await agent.update_chat_ctx(ctx_copia)
                    logger.info(f"[Mem0] {len(memorias)} memórias injetadas no contexto.")
        except Exception as e:
            logger.error(f"[Mem0] Erro ao carregar memória: {e}")

    # ── Salvar Memória ao Desligar (opcional) ──
    async def shutdown_hook():
        if not mem0_client:
            return
        try:
            msgs = []
            for item in session._agent.chat_ctx.items:
                if not hasattr(item, "content") or not item.content:
                    continue
                if item.role not in ("user", "assistant"):
                    continue
                conteudo = "".join(item.content) if isinstance(item.content, list) else str(item.content)
                conteudo = conteudo.strip()
                if conteudo:
                    msgs.append({"role": item.role, "content": conteudo})
            if msgs:
                await mem0_client.add(msgs, user_id=user_id)
                logger.info(f"[Mem0] {len(msgs)} mensagens salvas na memória.")
        except Exception as e:
            logger.warning(f"[Mem0] Erro ao salvar memória: {e}")

    ctx.add_shutdown_callback(shutdown_hook)

    await session.generate_reply(
        instructions=SESSION_INSTRUCTION + "\nCumprimente o usuário de forma natural e confiante."
    )


if __name__ == "__main__":
    agents.cli.run_app(agents.WorkerOptions(entrypoint_fnc=entrypoint))
