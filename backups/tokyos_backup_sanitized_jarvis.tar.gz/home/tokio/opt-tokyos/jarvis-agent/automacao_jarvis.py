import os
import shutil
import webbrowser
import zipfile
import subprocess
import re

HAVE_PULSE = False
try:
    import pulsectl
    HAVE_PULSE = True
except ImportError:
    pass

HAVE_BRIGHTNESS = False
try:
    import screen_brightness_control as sbc
    HAVE_BRIGHTNESS = True
except ImportError:
    pass

class JarvisControl:
    def __init__(self):
        self.shortcuts = {
            "youtube": "https://www.youtube.com",
            "github": "https://www.github.com",
            "chatgpt": "https://chat.openai.com",
            "google": "https://www.google.com",
            "instagram": "https://www.instagram.com"
        }
        self.home = os.path.expanduser('~')
        self.desktop = os.path.join(self.home, 'Desktop')
        self.documents = os.path.join(self.home, 'Documents')
        self.downloads = os.path.join(self.home, 'Downloads')
        self.base_folders = {
            "area de trabalho": self.desktop,
            "área de trabalho": self.desktop,
            "desktop": self.desktop,
            "documentos": self.documents,
            "documents": self.documents,
            "downloads": self.downloads
        }
        self.ignore_folders = {
            "venv", ".venv", "env", "node_modules", "__pycache__", ".git", ".idea", ".vscode"
        }

    def _resolver_caminho(self, caminho):
        caminho = caminho.strip('\'"').replace('\\', '/')
        caminho_lower = caminho.lower()
        for alias, real_path in self.base_folders.items():
            if caminho_lower == alias:
                return real_path
            if caminho_lower.startswith(alias + "/"):
                return os.path.abspath(os.path.join(real_path, caminho[len(alias)+1:]))
        if not os.path.isabs(caminho) and not caminho.startswith('.'):
            return os.path.abspath(os.path.join(self.desktop, caminho))
        return os.path.abspath(os.path.expanduser(caminho))

    def _walk_seguro(self, base):
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if d not in self.ignore_folders and not d.startswith('.')]
            yield dirpath, dirnames, filenames

    def _xdg_open(self, path):
        subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def cria_pasta(self, caminho):
        try:
            caminho_abs = self._resolver_caminho(caminho)
            os.makedirs(caminho_abs, exist_ok=True)
            return f"Pasta criada com sucesso: {caminho_abs}"
        except Exception as e:
            return f"Erro ao criar pasta: {str(e)}"

    def abrir_pasta(self, nome_pasta):
        try:
            caminho_direto = self.base_folders.get(nome_pasta.lower())
            if caminho_direto and os.path.exists(caminho_direto):
                self._xdg_open(caminho_direto)
                return f"Abrindo {nome_pasta}."
            for base_name, base_path in self.base_folders.items():
                if base_name in ["area de trabalho", "documentos", "downloads"]:
                    for dirpath, dirnames, _ in self._walk_seguro(base_path):
                        for d in dirnames:
                            if d.lower() == nome_pasta.lower():
                                full_path = os.path.join(dirpath, d)
                                self._xdg_open(full_path)
                                return f"Pasta encontrada e aberta em: {full_path}"
            return f"Pasta '{nome_pasta}' não encontrada nos locais padrão."
        except Exception as e:
            return f"Erro ao abrir pasta: {str(e)}"

    def buscar_e_abrir_arquivo(self, nome_arquivo):
        try:
            for _, base_path in self.base_folders.items():
                for dirpath, _, filenames in self._walk_seguro(base_path):
                    for f in filenames:
                        if nome_arquivo.lower() in f.lower():
                            full_path = os.path.join(dirpath, f)
                            self._xdg_open(full_path)
                            return f"Arquivo encontrado e aberto: {full_path}"
            return f"Arquivo '{nome_arquivo}' não encontrado."
        except Exception as e:
            return f"Erro ao buscar/abrir arquivo: {str(e)}"

    def deletar_arquivo(self, caminho):
        try:
            path_abs = self._resolver_caminho(caminho)
            if os.path.isfile(path_abs):
                os.remove(path_abs)
                return f"Arquivo deletado: {path_abs}"
            elif os.path.isdir(path_abs):
                shutil.rmtree(path_abs)
                return f"Diretório deletado: {path_abs}"
            return f"Caminho não encontrado: {path_abs}"
        except Exception as e:
            return f"Erro ao deletar: {str(e)}"

    def limpar_diretorio(self, caminho):
        try:
            path_abs = self._resolver_caminho(caminho)
            if os.path.exists(path_abs):
                for item in os.listdir(path_abs):
                    item_path = os.path.join(path_abs, item)
                    if os.path.isfile(item_path): os.remove(item_path)
                    elif os.path.isdir(item_path): shutil.rmtree(item_path)
                return f"Diretório limpo: {path_abs}"
            return "Diretório não encontrado."
        except Exception as e:
            return f"Erro ao limpar diretório: {str(e)}"

    def mover_item(self, origem, destino):
        try:
            origem_abs = self._resolver_caminho(origem)
            destino_abs = self._resolver_caminho(destino)
            shutil.move(origem_abs, destino_abs)
            return f"Movido de {origem_abs} para {destino_abs}."
        except Exception as e:
            return f"Erro ao mover: {str(e)}"

    def copiar_item(self, origem, destino):
        try:
            origem_abs = self._resolver_caminho(origem)
            destino_abs = self._resolver_caminho(destino)
            if os.path.isdir(origem_abs): shutil.copytree(origem_abs, destino_abs)
            else: shutil.copy2(origem_abs, destino_abs)
            return f"Copiado de {origem_abs} para {destino_abs}."
        except Exception as e:
            return f"Erro ao copiar: {str(e)}"

    def renomear_item(self, caminho, novo_nome):
        try:
            path_abs = self._resolver_caminho(caminho)
            diretorio = os.path.dirname(path_abs)
            novo_caminho = os.path.join(diretorio, novo_nome)
            os.rename(path_abs, novo_caminho)
            return f"Renomeado para {novo_nome}."
        except Exception as e:
            return f"Erro ao renomear: {str(e)}"

    def organizar_pasta(self, caminho):
        try:
            path_abs = self._resolver_caminho(caminho)
            extensoes = {
                'Imagens': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'],
                'Documentos': ['.pdf', '.doc', '.docx', '.txt', '.xlsx', '.pptx', '.csv'],
                'Videos': ['.mp4', '.mkv', '.avi', '.mov'],
                'Musicas': ['.mp3', '.wav', '.flac'],
                'Compactados': ['.zip', '.rar', '.7z'],
                'Executaveis': ['.AppImage', '.deb', '.sh', '.bin']
            }
            for item in os.listdir(path_abs):
                item_path = os.path.join(path_abs, item)
                if os.path.isfile(item_path):
                    ext = os.path.splitext(item)[1].lower()
                    movido = False
                    for pasta, exts in extensoes.items():
                        if ext in exts:
                            pasta_destino = os.path.join(path_abs, pasta)
                            os.makedirs(pasta_destino, exist_ok=True)
                            shutil.move(item_path, os.path.join(pasta_destino, item))
                            movido = True
                            break
                    if not movido:
                        pasta_outros = os.path.join(path_abs, 'Outros')
                        os.makedirs(pasta_outros, exist_ok=True)
                        shutil.move(item_path, os.path.join(pasta_outros, item))
            return "Pasta organizada com sucesso."
        except Exception as e:
            return f"Erro ao organizar pasta: {str(e)}"

    def compactar_pasta(self, caminho):
        try:
            path_abs = self._resolver_caminho(caminho).rstrip('/\\')
            shutil.make_archive(path_abs, 'zip', path_abs)
            return f"Compactado em: {path_abs}.zip"
        except Exception as e:
            return f"Erro ao compactar: {str(e)}"

    def controle_volume(self, nivel):
        try:
            nivel = max(0, min(100, int(nivel)))
            if HAVE_PULSE:
                with pulsectl.Pulse('jarvis-control') as pulse:
                    for sink in pulse.sink_list():
                        pulse.volume_set_all_chans(sink, nivel / 100)
                return f"Volume ajustado para {nivel}%."
            else:
                subprocess.run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{nivel}%"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return f"Volume ajustado para {nivel}%."
        except Exception as e:
            return f"Erro ao ajustar volume: {str(e)}"

    def controle_brilho(self, nivel):
        try:
            nivel = max(0, min(100, int(nivel)))
            if HAVE_BRIGHTNESS:
                sbc.set_brightness(nivel)
                return f"Brilho ajustado para {nivel}%."
            subprocess.run(["brightnessctl", "set", f"{nivel}%"],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"Brilho ajustado para {nivel}%."
        except Exception as e:
            return f"Erro ao ajustar brilho: {str(e)}"

    def abrir_aplicativo(self, nome_app):
        try:
            apps = {
                "bloco de notas": "gedit",
                "calculadora": "gnome-calculator",
                "paint": "kolourpaint",
                "terminal": "deepin-terminal",
                "navegador": "google-chrome",
                "word": "libreoffice --writer",
                "excel": "libreoffice --calc",
                "powerpoint": "libreoffice --impress",
                "explorador de arquivos": "dde-file-manager",
                "configuracoes": "deepin-system-settings",
                "vscode": "code",
                "spotify": "spotify",
            }
            comando = apps.get(nome_app.lower())
            if comando:
                subprocess.Popen(comando.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return f"Abrindo {nome_app}."
            subprocess.Popen([nome_app], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"Tentando abrir {nome_app}."
        except Exception as e:
            return f"Erro ao abrir aplicativo: {str(e)}"

    def atalhos_navegacao(self, site):
        try:
            url = self.shortcuts.get(site.lower())
            if url:
                self._xdg_open(url)
                return f"Abrindo {site}."
            return "Site não cadastrado."
        except Exception as e:
            return f"Erro ao abrir site: {str(e)}"

    def pesquisar_no_google(self, termo):
        try:
            import urllib.parse
            url = f"https://www.google.com/search?q={urllib.parse.quote_plus(termo)}"
            self._xdg_open(url)
            return f"Pesquisando por {termo}."
        except Exception as e:
            return f"Erro ao pesquisar: {str(e)}"

    def energia_pc(self, acao):
        try:
            if acao == "desligar":
                subprocess.run(["systemctl", "poweroff"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return "Desligando o computador."
            elif acao == "reiniciar":
                subprocess.run(["systemctl", "reboot"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return "Reiniciando o computador."
            elif acao in ("bloquear", "bloqueio", "lock"):
                subprocess.run(["xdg-screensaver", "lock"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return "Computador bloqueado."
            return "Ação inválida."
        except Exception as e:
            return f"Erro: {str(e)}"

    def abrir_arquivo(self, caminho):
        try:
            path_abs = self._resolver_caminho(caminho)
            if os.path.exists(path_abs):
                self._xdg_open(path_abs)
                return f"Abrindo arquivo {path_abs}."
            return f"Arquivo não encontrado: {path_abs}"
        except Exception as e:
            return f"Erro ao abrir arquivo: {str(e)}"
