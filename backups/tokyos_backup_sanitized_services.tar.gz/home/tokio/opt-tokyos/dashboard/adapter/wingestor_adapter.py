import os
import re
import json
import logging
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
from db.database_manager import DatabaseManager

load_dotenv()

logger = logging.getLogger(__name__)

WINGESTOR_URL = os.getenv("WINGESTOR_URL", "https://app.wingestor.com.br")
SYNC_INTERVAL_MINUTES = int(os.getenv("WINGESTOR_SYNC_INTERVAL_MINUTES", "5"))
CIRCUIT_BREAKER_THRESHOLD = 3
_failures = 0
_circuit_open_until: datetime | None = None

EMPRESA_ID = 14
USUARIO_ID = 17

LOCAIS = [
    {"local_id": "12", "store_id": "riverside", "store_name": "Riverside"},
    {"local_id": "13", "store_id": "teresina", "store_name": "Teresina"},
]


def _month_range() -> tuple[str, str]:
    now = datetime.now(timezone.utc) - timedelta(hours=3)
    start = f"{now.year:04d}-{now.month:02d}-01"
    end = now.strftime("%Y-%m-%d")
    return start, end


class WingestorAdapter:
    def __init__(self, db: DatabaseManager | None = None):
        self.db = db or DatabaseManager()

    async def sync_all_stores(self) -> dict:
        global _failures, _circuit_open_until

        if _circuit_open_until and datetime.now(timezone.utc) < _circuit_open_until:
            logger.warning("Circuit breaker open, using cache")
            return self._cached_response("Circuit breaker open")

        try:
            from playwright.async_api import async_playwright

            async with async_playwright() as pw:
                browser = await pw.chromium.launch(headless=True)
                ctx = await browser.new_context(
                    locale="pt-BR",
                    timezone_id="America/Sao_Paulo",
                )
                page = await ctx.new_page()
                await self._login(page)
                await self._sync_daily_sales(page)
                await self._sync_per_store(page)
                await self._sync_monthly_reports(page)
                await browser.close()

            _failures = 0
            _circuit_open_until = None
            now = datetime.now(timezone.utc).isoformat()
            stores = self.db.get_all_stores()
            return {"status": "synced", "stores": stores, "last_sync": now}

        except Exception as e:
            _failures += 1
            if _failures >= CIRCUIT_BREAKER_THRESHOLD:
                _circuit_open_until = datetime.now(timezone.utc)
                logger.warning(f"Circuit breaker opened after {_failures} failures")
            logger.error(f"WinGestor sync failed: {e}")
            return self._cached_response(str(e))

    async def _login(self, page) -> None:
        email = os.getenv("WINGESTOR_EMAIL", "")
        password = os.getenv("WINGESTOR_PASSWORD", "")
        await page.goto(WINGESTOR_URL, timeout=20000)
        await page.wait_for_timeout(1000)
        email_input = page.locator('input[type="email"]').first
        await email_input.fill(email)
        pwd_input = page.locator('input[type="password"]').first
        await pwd_input.fill(password)
        await page.locator('button[type="submit"]').first.click()
        await page.wait_for_timeout(3000)
        logger.info("Login realizado")

    async def _api_get(self, page, path: str) -> any:
        return await page.evaluate(f"""
            fetch('{path}')
                .then(r => r.json())
                .catch(() => null)
        """)

    async def _sync_daily_sales(self, page) -> None:
        vendas = await self._api_get(page, f"/api/graficos/grafico-vendas-mes?empresa_id={EMPRESA_ID}")
        if not vendas or not isinstance(vendas, list):
            logger.warning("grafico-vendas-mes retornou dados inválidos")
            return

        now = datetime.now(timezone.utc) - timedelta(hours=3)
        year = now.year
        month = now.month

        total_mensal = sum(item.get("valor", 0) for item in vendas)
        logger.info(f"Vendas mensais (consolidado): R$ {total_mensal:,.2f}")

        armazenados = 0
        for item in vendas:
            parts = item.get("dia", "").split("/")
            if len(parts) != 2:
                continue
            dia, mes = int(parts[0]), int(parts[1])
            if mes != month:
                continue
            valor = float(item.get("valor", 0))
            date_str = f"{year:04d}-{month:02d}-{dia:02d}"

            self.db.upsert_daily_record({
                "store_id": "consolidado",
                "date": date_str,
                "revenue": valor,
                "sales_count": 0,
                "products_count": 0,
                "ticket_avg": 0,
            })
            armazenados += 1

        logger.info(f"Daily sales synced: {armazenados} days, total R$ {total_mensal:,.2f}")

    async def _sync_per_store(self, page) -> None:
        now = datetime.now(timezone.utc) - timedelta(hours=3)
        year = now.year
        month = now.month

        for local in LOCAIS:
            try:
                cards = await self._api_get(page,
                    f"/api/graficos/dados-cards?empresa_id={EMPRESA_ID}&usuario_id={USUARIO_ID}&periodo=30&local_id={local['local_id']}"
                )
                if not cards:
                    logger.warning(f"dados-cards sem resposta para {local['store_name']}")
                    continue

                vendas_30d = float(cards.get("vendas", 0))
                compras_30d = float(cards.get("compras", 0))
                clientes = int(cards.get("clientes", 0))
                produtos = int(cards.get("produtos", 0))

                dia_util = now.day if now.day > 0 else 1
                daily_revenue = round(vendas_30d / dia_util, 2)

                store_data = {
                    "store_id": local["store_id"],
                    "store_name": local["store_name"],
                    "daily_revenue": daily_revenue,
                    "daily_goal": 0,
                    "monthly_goal": 0,
                    "monthly_revenue": round(vendas_30d, 2),
                    "ticket_avg": round(vendas_30d / max(clientes, 1), 2),
                    "sale_count": clientes,
                    "last_sync": datetime.now(timezone.utc).isoformat(),
                }
                self.db.upsert_store(store_data)

                record_data = {
                    "store_id": local["store_id"],
                    "year": year,
                    "month": month,
                    "monthly_goal": 0,
                    "daily_goal": 0,
                    "monthly_revenue": round(vendas_30d, 2),
                    "monthly_gap": 0,
                    "daily_revenue": daily_revenue,
                    "daily_gap": 0,
                    "ticket_avg_revenue": round(vendas_30d / max(clientes, 1), 2),
                    "ticket_avg_products": round(produtos / max(clientes, 1), 2),
                    "previous_day_revenue": daily_revenue,
                    "revenue_trend": "stable",
                    "working_days": dia_util,
                    "sales_count": clientes,
                    "products_sold_count": produtos,
                }
                self.db.upsert_monthly_record(record_data)
                logger.info(f"Store {local['store_name']}: R$ {vendas_30d:,.2f} (30d), R$ {daily_revenue:,.2f}/dia")

            except Exception as e:
                logger.warning(f"Per-store sync failed for {local['store_name']}: {e}")

    async def _sync_monthly_reports(self, page) -> None:
        pass

    def _cached_response(self, error_msg: str) -> dict:
        stores = self.db.get_all_stores()
        last_sync = self.db.get_last_sync()
        return {"status": "error", "error": error_msg, "stores": stores, "last_sync": last_sync}

    def get_cached_dashboard(self) -> dict:
        stores = self.db.get_all_stores()
        last_sync = self.db.get_last_sync()
        age = self.db.get_cache_age_minutes()
        enriched = []
        for s in stores:
            goal = s["monthly_goal"] or 1
            enriched.append({**s, "is_below_goal": (s["monthly_revenue"] / goal) * 100 < 80})
        return {"stores": enriched, "last_sync": last_sync, "cache_age_minutes": age}
