import os
import hashlib
from fastapi import APIRouter, Request, HTTPException, status
from fastapi.responses import JSONResponse

router = APIRouter()

TOKEN_COOKIE = "dashboard_token"
TOKEN_EXAMPLE = os.getenv("DASHBOARD_API_TOKEN", "tokio-dashboard-mvp-2026")
_tokens: set[str] = set()


def init():
    _tokens.add(hashlib.sha256(TOKEN_EXAMPLE.encode()).hexdigest())


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


async def auth_middleware(request: Request, call_next):
    if request.url.path in (
        "/api/v1/dashboard/health",
        "/api/v1/dashboard/login",
        "/docs",
        "/openapi.json",
    ):
        return await call_next(request)

    token = request.cookies.get(TOKEN_COOKIE)
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]

    if not token or _hash_token(token) not in _tokens:
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"detail": "Não autorizado. Faça login primeiro."},
        )

    return await call_next(request)


@router.post("/dashboard/login")
async def login(request: Request):
    body = await request.json()
    token = body.get("token", "")
    if _hash_token(token) in _tokens:
        response = JSONResponse({"status": "ok", "message": "Autenticado"})
        response.set_cookie(
            key=TOKEN_COOKIE,
            value=token,
            httponly=True,
            samesite="lax",
            max_age=86400 * 7,
        )
        return response
    raise HTTPException(status_code=401, detail="Token inválido")
