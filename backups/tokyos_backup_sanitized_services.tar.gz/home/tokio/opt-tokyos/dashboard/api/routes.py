import logging
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional
from db.database_manager import DatabaseManager
from adapter.wingestor_adapter import WingestorAdapter

logger = logging.getLogger(__name__)
router = APIRouter()
db = DatabaseManager()
adapter = WingestorAdapter(db=db)


class DelegateRequest(BaseModel):
    store_id: str
    delegated_by: str = "CEO"
    delegated_to: str
    instruction: str


class MonthlyRecordRequest(BaseModel):
    store_id: str
    year: int
    month: int
    monthly_goal: float = 0
    daily_goal: float = 0
    monthly_revenue: float = 0
    monthly_gap: float = 0
    daily_revenue: float = 0
    daily_gap: float = 0
    ticket_avg_revenue: float = 0
    ticket_avg_products: float = 0
    previous_day_revenue: float = 0
    revenue_trend: str = "stable"
    working_days: int = 0
    sales_count: int = 0
    products_sold_count: int = 0


class DreRequest(BaseModel):
    store_id: str
    year: int
    month: int
    gross_revenue: float = 0
    deductions: float = 0
    net_revenue: float = 0
    cogs: float = 0
    gross_profit: float = 0
    operating_expenses: float = 0
    payroll: float = 0
    rent: float = 0
    utilities: float = 0
    marketing: float = 0
    other_expenses: float = 0
    ebitda: float = 0
    financial_expenses: float = 0
    taxes: float = 0
    net_profit: float = 0


class CashFlowRequest(BaseModel):
    store_id: str
    year: int
    month: int
    opening_balance: float = 0
    inflows: float = 0
    outflows: float = 0
    closing_balance: float = 0


@router.get("/dashboard")
async def get_dashboard():
    try:
        cached = adapter.get_cached_dashboard()
        age = cached["cache_age_minutes"]

        if age > 5:
            return {
                **cached,
                "warning": "Dados podem estar desatualizados. Última sincronia há mais de 5 minutos.",
            }

        return cached

    except Exception as e:
        logger.error(f"Erro ao carregar dashboard: {e}")
        raise HTTPException(status_code=500, detail="Erro ao carregar dados do dashboard")


@router.post("/dashboard/sync")
async def sync_dashboard():
    result = await adapter.sync_all_stores()
    return result


@router.get("/dashboard/health")
async def health():
    last_sync = db.get_last_sync()
    age = db.get_cache_age_minutes()
    return {
        "status": "ok",
        "last_sync": last_sync,
        "cache_status": "empty" if last_sync is None else "cached",
        "cache_age_minutes": age,
    }


@router.get("/dashboard/sync/status")
async def sync_status():
    last_sync = db.get_last_sync()
    age = db.get_cache_age_minutes()
    return {
        "last_sync": last_sync,
        "cache_age_minutes": age,
        "is_stale": age > 10,
    }


@router.post("/dashboard/delegate")
async def delegate_action(req: DelegateRequest):
    if req.delegated_to not in ("COO", "CFO"):
        raise HTTPException(status_code=422, detail="Destino deve ser COO ou CFO")

    store = db.get_store(req.store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada")

    action_id = db.add_delegated_action(
        store_id=req.store_id,
        delegated_by=req.delegated_by,
        delegated_to=req.delegated_to,
        instruction=req.instruction,
    )

    logger.info(f"Ação delegada #{action_id}: {req.delegated_by} → {req.delegated_to} para loja {req.store_id}")

    return {
        "status": "delegated",
        "action_id": action_id,
        "message": f"Ação delegada para {req.delegated_to} com sucesso",
    }


@router.get("/dashboard/delegated")
async def list_delegated(store_id: Optional[str] = None):
    actions = db.get_delegated_actions(store_id)
    return {"actions": actions}


@router.get("/dashboard/geral")
async def get_geral(year: Optional[int] = None, month: Optional[int] = None):
    stores = [s for s in db.get_all_stores() if s["store_id"] != "consolidado"]
    records = [r for r in db.get_monthly_records(year=year, month=month) if r["store_id"] != "consolidado"]

    total_lojas = len(stores)
    total_revenue = sum(r["monthly_revenue"] for r in records)
    total_goal = sum(r["monthly_goal"] for r in records)
    total_gap = sum(r["monthly_gap"] for r in records)
    total_sales = sum(r["sales_count"] for r in records)
    total_products = sum(r["products_sold_count"] for r in records)
    total_daily_revenue = sum(r["daily_revenue"] for r in records)
    total_daily_goal = sum(r["daily_goal"] for r in records)
    total_daily_gap = sum(r["daily_gap"] for r in records)
    total_prev_day_revenue = sum(r["previous_day_revenue"] for r in records)
    total_working_days = sum(r["working_days"] for r in records)

    avg_ticket_revenue = total_revenue / total_sales if total_sales > 0 else 0
    avg_ticket_products = total_products / total_sales if total_sales > 0 else 0

    overall_trend = "stable"
    if records:
        trends = [r["revenue_trend"] for r in records]
        if trends.count("up") > trends.count("down"):
            overall_trend = "up"
        elif trends.count("down") > trends.count("up"):
            overall_trend = "down"

    dre_records = db.get_dre(year=year, month=month)
    dre_consolidado = {}
    if dre_records:
        dre_consolidado = {
            "gross_revenue": sum(r["gross_revenue"] for r in dre_records),
            "deductions": sum(r["deductions"] for r in dre_records),
            "net_revenue": sum(r["net_revenue"] for r in dre_records),
            "cogs": sum(r["cogs"] for r in dre_records),
            "gross_profit": sum(r["gross_profit"] for r in dre_records),
            "operating_expenses": sum(r["operating_expenses"] for r in dre_records),
            "payroll": sum(r["payroll"] for r in dre_records),
            "rent": sum(r["rent"] for r in dre_records),
            "utilities": sum(r["utilities"] for r in dre_records),
            "marketing": sum(r["marketing"] for r in dre_records),
            "other_expenses": sum(r["other_expenses"] for r in dre_records),
            "ebitda": sum(r["ebitda"] for r in dre_records),
            "financial_expenses": sum(r["financial_expenses"] for r in dre_records),
            "taxes": sum(r["taxes"] for r in dre_records),
            "net_profit": sum(r["net_profit"] for r in dre_records),
        }

    cash_records = db.get_cash_flow(year=year, month=month)
    cash_consolidado = {}
    if cash_records:
        cash_consolidado = {
            "opening_balance": sum(r["opening_balance"] for r in cash_records),
            "inflows": sum(r["inflows"] for r in cash_records),
            "outflows": sum(r["outflows"] for r in cash_records),
            "closing_balance": sum(r["closing_balance"] for r in cash_records),
        }

    return {
        "total_stores": total_lojas,
        "summary": {
            "monthly_revenue": total_revenue,
            "monthly_goal": total_goal,
            "monthly_gap": total_gap,
            "daily_revenue": total_daily_revenue,
            "daily_goal": total_daily_goal,
            "daily_gap": total_daily_gap,
            "previous_day_revenue": total_prev_day_revenue,
            "ticket_avg_revenue": round(avg_ticket_revenue, 2),
            "ticket_avg_products": round(avg_ticket_products, 2),
            "sales_count": total_sales,
            "products_sold_count": total_products,
            "working_days": total_working_days,
            "revenue_trend": overall_trend,
        },
        "dre": dre_consolidado,
        "cash_flow": cash_consolidado,
        "year": year,
        "month": month,
    }


@router.get("/dashboard/lojas")
async def get_lojas(year: Optional[int] = None, month: Optional[int] = None):
    stores = [s for s in db.get_all_stores() if s["store_id"] != "consolidado"]
    records = [r for r in db.get_monthly_records(year=year, month=month) if r["store_id"] != "consolidado"]
    records_by_store = {r["store_id"]: r for r in records}

    result = []
    for s in stores:
        r = records_by_store.get(s["store_id"])
        if r:
            result.append({
                "store_id": s["store_id"],
                "store_name": s["store_name"],
                "monthly_revenue": r["monthly_revenue"],
                "monthly_goal": r["monthly_goal"],
                "monthly_gap": r["monthly_gap"],
                "daily_revenue": r["daily_revenue"],
                "daily_goal": r["daily_goal"],
                "daily_gap": r["daily_gap"],
                "ticket_avg_revenue": r["ticket_avg_revenue"],
                "ticket_avg_products": r["ticket_avg_products"],
                "previous_day_revenue": r["previous_day_revenue"],
                "revenue_trend": r["revenue_trend"],
                "working_days": r["working_days"],
                "sales_count": r["sales_count"],
                "products_sold_count": r["products_sold_count"],
                "year": r["year"],
                "month": r["month"],
            })

    return {"lojas": result, "year": year, "month": month}


@router.get("/dashboard/loja/{store_id}")
async def get_loja_detail(store_id: str, year: Optional[int] = None, month: Optional[int] = None):
    store = db.get_store(store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada")

    records = db.get_monthly_records(store_id=store_id)
    dre_records = db.get_dre(store_id=store_id, year=year, month=month)
    cash_records = db.get_cash_flow(store_id=store_id, year=year, month=month)

    current = None
    if year and month:
        for r in records:
            if r["year"] == year and r["month"] == month:
                current = r
                break

    return {
        "store": dict(store),
        "historico": records,
        "current": current,
        "dre": [dict(r) for r in dre_records],
        "cash_flow": [dict(r) for r in cash_records],
    }


@router.post("/dashboard/registrar")
async def registrar_mensal(req: MonthlyRecordRequest):
    store = db.get_store(req.store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada")

    if req.revenue_trend not in ("up", "down", "stable"):
        raise HTTPException(status_code=422, detail="Tendência deve ser up, down ou stable")

    data = req.model_dump()
    db.upsert_monthly_record(data)
    logger.info(f"Registro mensal salvo: {req.store_id} {req.year}-{req.month:02d}")
    return {"status": "ok", "message": "Registro mensal salvo com sucesso"}


@router.post("/dashboard/dre/registrar")
async def registrar_dre(req: DreRequest):
    store = db.get_store(req.store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada")

    data = req.model_dump()
    db.upsert_dre(data)
    logger.info(f"DRE salvo: {req.store_id} {req.year}-{req.month:02d}")
    return {"status": "ok", "message": "DRE salvo com sucesso"}


@router.post("/dashboard/fluxo-caixa/registrar")
async def registrar_fluxo_caixa(req: CashFlowRequest):
    store = db.get_store(req.store_id)
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada")

    data = req.model_dump()
    db.upsert_cash_flow(data)
    logger.info(f"Fluxo de caixa salvo: {req.store_id} {req.year}-{req.month:02d}")
    return {"status": "ok", "message": "Fluxo de caixa salvo com sucesso"}
