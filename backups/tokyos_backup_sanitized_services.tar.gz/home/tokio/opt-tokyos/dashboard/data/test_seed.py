import sys, os, math
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from db.init_db import init_db, get_connection

init_db()
conn = get_connection()

stores = [
    ('loja-01', 'Bunny Dreams Teresina Shopping', 4520.00, 5000.00, 150000.00, 98500.00, 85.50, 53, '2026-05-24T10:00:00'),
    ('loja-02', 'Bunny Dreams Riverside', 2100.00, 4000.00, 120000.00, 62000.00, 72.00, 29, '2026-05-24T10:00:00'),
]
for s in stores:
    conn.execute("""
        INSERT OR REPLACE INTO store_cache
        (store_id, store_name, daily_revenue, daily_goal, monthly_goal, monthly_revenue, ticket_avg, sale_count, last_sync)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, s)
conn.commit()

now = datetime.now()
current_year = now.year
current_month = now.month

lojas = [
    {"id": "loja-01", "nome": "Bunny Dreams Teresina Shopping", "meta_mes": 150000, "receita_base": 98500},
    {"id": "loja-02", "nome": "Bunny Dreams Riverside",        "meta_mes": 120000, "receita_base": 62000},
]

meses_br = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho",
            "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"]

for loja in lojas:
    for delta in range(5, -1, -1):
        y = current_year
        m = current_month - delta
        while m <= 0:
            m += 12
            y -= 1

        h = lambda s: hash(f"{loja['id']}-{s}-{y}-{m}")
        variacao = 1 + (delta * 0.03) + ((h('base') % 20) - 10) / 100

        monthly_goal    = round(loja['meta_mes'] * variacao, 2)
        daily_goal      = round(monthly_goal / 30, 2)
        monthly_revenue = round(loja['receita_base'] * variacao * (0.85 + (h('rev') % 15) / 100), 2)
        monthly_gap     = round(monthly_goal - monthly_revenue, 2)
        daily_revenue   = round(monthly_revenue / 30, 2)
        daily_gap       = round(daily_goal - daily_revenue, 2)
        sales_count     = int(monthly_revenue / (75 + (h('tk') % 20)))
        products_count  = int(sales_count * (2.5 + (h('prod') % 5) / 10))
        prev_day_rev    = round(daily_revenue * (0.85 + (h('prev') % 20) / 100), 2)
        ticket_rev      = round(monthly_revenue / sales_count, 2) if sales_count > 0 else 0
        ticket_prod     = round(products_count / sales_count, 2) if sales_count > 0 else 0
        trend = "up" if monthly_revenue > monthly_goal * 0.9 else ("down" if monthly_revenue < monthly_goal * 0.7 else "stable")

        conn.execute("""
            INSERT OR REPLACE INTO monthly_records
            (store_id, year, month, monthly_goal, daily_goal, monthly_revenue, monthly_gap,
             daily_revenue, daily_gap, ticket_avg_revenue, ticket_avg_products,
             previous_day_revenue, revenue_trend, working_days, sales_count, products_sold_count)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (loja['id'], y, m, monthly_goal, daily_goal, monthly_revenue, monthly_gap,
              daily_revenue, daily_gap, ticket_rev, ticket_prod,
              prev_day_rev, trend, 30, sales_count, products_count))

        gross_revenue   = round(monthly_revenue, 2)
        deductions      = round(gross_revenue * 0.12, 2)
        net_revenue     = round(gross_revenue - deductions, 2)
        cogs            = round(net_revenue * 0.35, 2)
        gross_profit    = round(net_revenue - cogs, 2)
        op_exp          = round(gross_profit * 0.30, 2)
        payroll         = round(gross_profit * 0.15, 2)
        rent            = round(gross_profit * 0.07, 2)
        utilities       = round(gross_profit * 0.03, 2)
        marketing       = round(gross_profit * 0.04, 2)
        other           = round(gross_profit * 0.01, 2)
        ebitda          = round(gross_profit - op_exp, 2)
        fin_exp         = round(ebitda * 0.05, 2)
        taxes           = round(ebitda * 0.15, 2)
        net_profit      = round(ebitda - fin_exp - taxes, 2)

        conn.execute("""
            INSERT OR REPLACE INTO dre_records
            (store_id, year, month, gross_revenue, deductions, net_revenue, cogs,
             gross_profit, operating_expenses, payroll, rent, utilities, marketing,
             other_expenses, ebitda, financial_expenses, taxes, net_profit)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (loja['id'], y, m, gross_revenue, deductions, net_revenue, cogs,
              gross_profit, op_exp, payroll, rent, utilities, marketing,
              other, ebitda, fin_exp, taxes, net_profit))

        opening = round((monthly_goal * 0.15) * (1 + (h('cf') % 20 - 10) / 100), 2)
        inflows  = round(net_revenue * 0.95, 2)
        outflows = round(inflows * 0.88, 2)
        closing  = round(opening + inflows - outflows, 2)

        conn.execute("""
            INSERT OR REPLACE INTO cash_flow_records
            (store_id, year, month, opening_balance, inflows, outflows, closing_balance)
            VALUES (?,?,?,?,?,?,?)
        """, (loja['id'], y, m, opening, inflows, outflows, closing))

        print(f"  {loja['id']} {meses_br[m-1]}/{y}: meta=R${monthly_goal:,.0f} rev=R${monthly_revenue:,.0f} gap=R${monthly_gap:,.0f}")

conn.commit()

for t in ['store_cache','monthly_records','dre_records','cash_flow_records']:
    c = conn.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
    print(f'  {t}: {c} registros')

print("Seed completo!")
