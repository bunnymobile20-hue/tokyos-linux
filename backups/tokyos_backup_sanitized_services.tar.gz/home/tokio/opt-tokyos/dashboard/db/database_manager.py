from db.init_db import get_connection


class DatabaseManager:
    def get_all_stores(self) -> list[dict]:
        conn = get_connection()
        rows = conn.execute("SELECT * FROM store_cache ORDER BY store_name").fetchall()
        return [dict(r) for r in rows]

    def upsert_store(self, store: dict):
        conn = get_connection()
        conn.execute("""
            INSERT INTO store_cache (store_id, store_name, daily_revenue, daily_goal,
                monthly_goal, monthly_revenue, ticket_avg, sale_count, last_sync, updated_at)
            VALUES (:store_id, :store_name, :daily_revenue, :daily_goal,
                :monthly_goal, :monthly_revenue, :ticket_avg, :sale_count, :last_sync, datetime('now'))
            ON CONFLICT(store_id) DO UPDATE SET
                store_name = excluded.store_name,
                daily_revenue = excluded.daily_revenue,
                daily_goal = excluded.daily_goal,
                monthly_goal = excluded.monthly_goal,
                monthly_revenue = excluded.monthly_revenue,
                ticket_avg = excluded.ticket_avg,
                sale_count = excluded.sale_count,
                last_sync = excluded.last_sync,
                updated_at = datetime('now')
        """, store)
        conn.commit()

    def get_last_sync(self) -> str | None:
        conn = get_connection()
        row = conn.execute("SELECT MAX(last_sync) as last_sync FROM store_cache").fetchone()
        return row["last_sync"] if row and row["last_sync"] else None

    def get_cache_age_minutes(self) -> int:
        conn = get_connection()
        row = conn.execute("""
            SELECT CAST(julianday('now') - julianday(MAX(last_sync)) AS INTEGER) * 1440 AS age
            FROM store_cache
        """).fetchone()
        return row["age"] if row and row["age"] else 999

    def get_store(self, store_id: str) -> dict | None:
        conn = get_connection()
        row = conn.execute("SELECT * FROM store_cache WHERE store_id = ?", (store_id,)).fetchone()
        return dict(row) if row else None

    def add_delegated_action(self, store_id: str, delegated_by: str, delegated_to: str, instruction: str) -> int:
        conn = get_connection()
        cur = conn.execute("""
            INSERT INTO delegated_actions (store_id, delegated_by, delegated_to, instruction)
            VALUES (?, ?, ?, ?)
        """, (store_id, delegated_by, delegated_to, instruction))
        conn.commit()
        return cur.lastrowid

    def get_delegated_actions(self, store_id: str | None = None) -> list[dict]:
        conn = get_connection()
        if store_id:
            rows = conn.execute(
                "SELECT * FROM delegated_actions WHERE store_id = ? ORDER BY created_at DESC",
                (store_id,)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM delegated_actions ORDER BY created_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def get_monthly_records(self, store_id: str | None = None, year: int | None = None, month: int | None = None) -> list[dict]:
        conn = get_connection()
        query = "SELECT * FROM monthly_records WHERE 1=1"
        params = []
        if store_id:
            query += " AND store_id = ?"
            params.append(store_id)
        if year:
            query += " AND year = ?"
            params.append(year)
        if month:
            query += " AND month = ?"
            params.append(month)
        query += " ORDER BY year DESC, month DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def upsert_monthly_record(self, record: dict):
        conn = get_connection()
        conn.execute("""
            INSERT INTO monthly_records (store_id, year, month, monthly_goal, daily_goal,
                monthly_revenue, monthly_gap, daily_revenue, daily_gap,
                ticket_avg_revenue, ticket_avg_products, previous_day_revenue,
                revenue_trend, working_days, sales_count, products_sold_count, updated_at)
            VALUES (:store_id, :year, :month, :monthly_goal, :daily_goal,
                :monthly_revenue, :monthly_gap, :daily_revenue, :daily_gap,
                :ticket_avg_revenue, :ticket_avg_products, :previous_day_revenue,
                :revenue_trend, :working_days, :sales_count, :products_sold_count, datetime('now'))
            ON CONFLICT(store_id, year, month) DO UPDATE SET
                monthly_goal = excluded.monthly_goal,
                daily_goal = excluded.daily_goal,
                monthly_revenue = excluded.monthly_revenue,
                monthly_gap = excluded.monthly_gap,
                daily_revenue = excluded.daily_revenue,
                daily_gap = excluded.daily_gap,
                ticket_avg_revenue = excluded.ticket_avg_revenue,
                ticket_avg_products = excluded.ticket_avg_products,
                previous_day_revenue = excluded.previous_day_revenue,
                revenue_trend = excluded.revenue_trend,
                working_days = excluded.working_days,
                sales_count = excluded.sales_count,
                products_sold_count = excluded.products_sold_count,
                updated_at = datetime('now')
        """, record)
        conn.commit()

    def get_dre(self, store_id: str | None = None, year: int | None = None, month: int | None = None) -> list[dict]:
        conn = get_connection()
        query = "SELECT * FROM dre_records WHERE 1=1"
        params = []
        if store_id:
            query += " AND store_id = ?"
            params.append(store_id)
        if year:
            query += " AND year = ?"
            params.append(year)
        if month:
            query += " AND month = ?"
            params.append(month)
        query += " ORDER BY year DESC, month DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def upsert_dre(self, record: dict):
        conn = get_connection()
        conn.execute("""
            INSERT INTO dre_records (store_id, year, month, gross_revenue, deductions,
                net_revenue, cogs, gross_profit, operating_expenses, payroll,
                rent, utilities, marketing, other_expenses, ebitda,
                financial_expenses, taxes, net_profit)
            VALUES (:store_id, :year, :month, :gross_revenue, :deductions,
                :net_revenue, :cogs, :gross_profit, :operating_expenses, :payroll,
                :rent, :utilities, :marketing, :other_expenses, :ebitda,
                :financial_expenses, :taxes, :net_profit)
            ON CONFLICT(store_id, year, month) DO UPDATE SET
                gross_revenue = excluded.gross_revenue,
                deductions = excluded.deductions,
                net_revenue = excluded.net_revenue,
                cogs = excluded.cogs,
                gross_profit = excluded.gross_profit,
                operating_expenses = excluded.operating_expenses,
                payroll = excluded.payroll,
                rent = excluded.rent,
                utilities = excluded.utilities,
                marketing = excluded.marketing,
                other_expenses = excluded.other_expenses,
                ebitda = excluded.ebitda,
                financial_expenses = excluded.financial_expenses,
                taxes = excluded.taxes,
                net_profit = excluded.net_profit
        """, record)
        conn.commit()

    def get_cash_flow(self, store_id: str | None = None, year: int | None = None, month: int | None = None) -> list[dict]:
        conn = get_connection()
        query = "SELECT * FROM cash_flow_records WHERE 1=1"
        params = []
        if store_id:
            query += " AND store_id = ?"
            params.append(store_id)
        if year:
            query += " AND year = ?"
            params.append(year)
        if month:
            query += " AND month = ?"
            params.append(month)
        query += " ORDER BY year DESC, month DESC"
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]

    def upsert_cash_flow(self, record: dict):
        conn = get_connection()
        conn.execute("""
            INSERT INTO cash_flow_records (store_id, year, month, opening_balance, inflows, outflows, closing_balance)
            VALUES (:store_id, :year, :month, :opening_balance, :inflows, :outflows, :closing_balance)
            ON CONFLICT(store_id, year, month) DO UPDATE SET
                opening_balance = excluded.opening_balance,
                inflows = excluded.inflows,
                outflows = excluded.outflows,
                closing_balance = excluded.closing_balance
        """, record)
        conn.commit()

    def upsert_daily_record(self, record: dict):
        conn = get_connection()
        conn.execute("""
            INSERT INTO daily_records (store_id, date, revenue, sales_count, products_count, ticket_avg)
            VALUES (:store_id, :date, :revenue, :sales_count, :products_count, :ticket_avg)
            ON CONFLICT(store_id, date) DO UPDATE SET
                revenue = excluded.revenue,
                sales_count = excluded.sales_count,
                products_count = excluded.products_count,
                ticket_avg = excluded.ticket_avg
        """, record)
        conn.commit()
