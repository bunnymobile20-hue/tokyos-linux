import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'dashboard.db')
_connection: sqlite3.Connection | None = None


def get_db_path() -> str:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return DB_PATH


def get_connection() -> sqlite3.Connection:
    global _connection
    if _connection is None:
        _connection = sqlite3.connect(get_db_path(), timeout=5.0)
        _connection.row_factory = sqlite3.Row
        _connection.execute("PRAGMA journal_mode=WAL")
        _connection.execute("PRAGMA foreign_keys=ON")
    return _connection


def init_db():
    conn = get_connection()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS store_cache (
            store_id TEXT PRIMARY KEY,
            store_name TEXT NOT NULL,
            daily_revenue REAL NOT NULL DEFAULT 0,
            daily_goal REAL NOT NULL DEFAULT 0,
            monthly_goal REAL NOT NULL DEFAULT 0,
            monthly_revenue REAL NOT NULL DEFAULT 0,
            ticket_avg REAL NOT NULL DEFAULT 0,
            sale_count INTEGER NOT NULL DEFAULT 0,
            last_sync TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_store_cache_last_sync
            ON store_cache(last_sync);

        CREATE TABLE IF NOT EXISTS delegated_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_id TEXT NOT NULL,
            delegated_by TEXT NOT NULL,
            delegated_to TEXT NOT NULL CHECK (delegated_to IN ('COO', 'CFO')),
            instruction TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            completed_at TEXT,
            notes TEXT,
            FOREIGN KEY (store_id) REFERENCES store_cache(store_id)
        );

        CREATE INDEX IF NOT EXISTS idx_delegated_actions_status
            ON delegated_actions(status);

        CREATE INDEX IF NOT EXISTS idx_delegated_actions_store
            ON delegated_actions(store_id);

        CREATE TABLE IF NOT EXISTS monthly_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_id TEXT NOT NULL,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            monthly_goal REAL NOT NULL DEFAULT 0,
            daily_goal REAL NOT NULL DEFAULT 0,
            monthly_revenue REAL NOT NULL DEFAULT 0,
            monthly_gap REAL NOT NULL DEFAULT 0,
            daily_revenue REAL NOT NULL DEFAULT 0,
            daily_gap REAL NOT NULL DEFAULT 0,
            ticket_avg_revenue REAL NOT NULL DEFAULT 0,
            ticket_avg_products REAL NOT NULL DEFAULT 0,
            previous_day_revenue REAL NOT NULL DEFAULT 0,
            revenue_trend TEXT NOT NULL DEFAULT 'stable' CHECK (revenue_trend IN ('up','down','stable')),
            working_days INTEGER NOT NULL DEFAULT 0,
            sales_count INTEGER NOT NULL DEFAULT 0,
            products_sold_count INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(store_id, year, month),
            FOREIGN KEY (store_id) REFERENCES store_cache(store_id)
        );

        CREATE INDEX IF NOT EXISTS idx_monthly_records_store
            ON monthly_records(store_id, year, month);

        CREATE TABLE IF NOT EXISTS daily_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_id TEXT NOT NULL,
            date TEXT NOT NULL,
            revenue REAL NOT NULL DEFAULT 0,
            sales_count INTEGER NOT NULL DEFAULT 0,
            products_count INTEGER NOT NULL DEFAULT 0,
            ticket_avg REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(store_id, date),
            FOREIGN KEY (store_id) REFERENCES store_cache(store_id)
        );

        CREATE INDEX IF NOT EXISTS idx_daily_records_store_date
            ON daily_records(store_id, date);

        CREATE TABLE IF NOT EXISTS dre_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_id TEXT NOT NULL,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            gross_revenue REAL NOT NULL DEFAULT 0,
            deductions REAL NOT NULL DEFAULT 0,
            net_revenue REAL NOT NULL DEFAULT 0,
            cogs REAL NOT NULL DEFAULT 0,
            gross_profit REAL NOT NULL DEFAULT 0,
            operating_expenses REAL NOT NULL DEFAULT 0,
            payroll REAL NOT NULL DEFAULT 0,
            rent REAL NOT NULL DEFAULT 0,
            utilities REAL NOT NULL DEFAULT 0,
            marketing REAL NOT NULL DEFAULT 0,
            other_expenses REAL NOT NULL DEFAULT 0,
            ebitda REAL NOT NULL DEFAULT 0,
            financial_expenses REAL NOT NULL DEFAULT 0,
            taxes REAL NOT NULL DEFAULT 0,
            net_profit REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(store_id, year, month),
            FOREIGN KEY (store_id) REFERENCES store_cache(store_id)
        );

        CREATE INDEX IF NOT EXISTS idx_dre_records_store
            ON dre_records(store_id, year, month);

        CREATE TABLE IF NOT EXISTS cash_flow_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            store_id TEXT NOT NULL,
            year INTEGER NOT NULL,
            month INTEGER NOT NULL,
            opening_balance REAL NOT NULL DEFAULT 0,
            inflows REAL NOT NULL DEFAULT 0,
            outflows REAL NOT NULL DEFAULT 0,
            closing_balance REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(store_id, year, month),
            FOREIGN KEY (store_id) REFERENCES store_cache(store_id)
        );

        CREATE INDEX IF NOT EXISTS idx_cash_flow_records_store
            ON cash_flow_records(store_id, year, month);
    """)

    conn.execute("""
        INSERT OR IGNORE INTO store_cache (store_id, store_name, daily_revenue, daily_goal, monthly_goal, monthly_revenue, ticket_avg, sale_count, last_sync)
        VALUES ('consolidado', 'Consolidado', 0, 0, 0, 0, 0, 0, datetime('now'))
    """)
    conn.execute("""
        INSERT OR IGNORE INTO store_cache (store_id, store_name, daily_revenue, daily_goal, monthly_goal, monthly_revenue, ticket_avg, sale_count, last_sync)
        VALUES ('riverside', 'Riverside', 0, 0, 0, 0, 0, 0, datetime('now'))
    """)
    conn.execute("""
        INSERT OR IGNORE INTO store_cache (store_id, store_name, daily_revenue, daily_goal, monthly_goal, monthly_revenue, ticket_avg, sale_count, last_sync)
        VALUES ('teresina', 'Teresina', 0, 0, 0, 0, 0, 0, datetime('now'))
    """)
    conn.commit()
