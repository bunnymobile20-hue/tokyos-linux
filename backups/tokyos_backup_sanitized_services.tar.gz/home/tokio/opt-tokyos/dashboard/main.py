import logging
import sys
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from db.init_db import init_db
from api.routes import router as dashboard_router
from api.auth import router as auth_router, auth_middleware, init as init_auth
from scheduler.sync_scheduler import start_scheduler, stop_scheduler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stdout,
)

app = FastAPI(title="Dashboard Executivo API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.middleware("http")(auth_middleware)
app.include_router(dashboard_router, prefix="/api/v1")
app.include_router(auth_router, prefix="/api/v1")


@app.on_event("startup")
def startup():
    init_db()
    init_auth()
    start_scheduler()


@app.on_event("shutdown")
def shutdown():
    stop_scheduler()


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=7071, reload=True)
