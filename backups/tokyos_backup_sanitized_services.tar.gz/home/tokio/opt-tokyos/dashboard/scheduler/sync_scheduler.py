import os
import asyncio
import logging
from datetime import datetime, timezone
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from adapter.wingestor_adapter import WingestorAdapter, SYNC_INTERVAL_MINUTES

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()
adapter = WingestorAdapter()


async def sync_job():
    logger.info("Scheduler: iniciando sincronia automática com WinGestor")
    try:
        result = await adapter.sync_all_stores()
        if result["status"] == "synced":
            logger.info(f"Scheduler: sincronia concluída — {len(result['stores'])} lojas")
        else:
            logger.warning(f"Scheduler: falha na sincronia — {result.get('error')}")
    except Exception as e:
        logger.error(f"Scheduler: erro inesperado na sincronia: {e}")


def start_scheduler():
    interval = max(1, SYNC_INTERVAL_MINUTES)
    scheduler.add_job(sync_job, "interval", minutes=interval, id="wingestor_sync")
    scheduler.start()
    logger.info(f"Scheduler iniciado — sincronia a cada {interval} minuto(s)")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Scheduler parado")
