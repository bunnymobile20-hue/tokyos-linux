import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from adapter.wingestor_adapter import WingestorAdapter


@pytest.fixture
def adapter():
    db_mock = MagicMock()
    db_mock.get_cache.return_value = None
    adapter = WingestorAdapter(db=db_mock)
    return adapter


@pytest.mark.asyncio
async def test_sync_all_stores_success(adapter):
    with patch("adapter.wingestor_adapter.async_playwright") as mock_pw:
        mock_browser = AsyncMock()
        mock_page = AsyncMock()
        mock_pw.return_value.start.return_value.__aenter__.return_value.chromium.launch.return_value = mock_browser
        mock_browser.new_page.return_value = mock_page
        mock_page.goto.return_value = None

        mock_page.locator.return_value.input_value.return_value = "user"
        mock_page.locator.return_value.click.return_value = None

        mock_page.content.return_value = """
        <table>
            <tr><td>Loja A</td><td>5000.00</td><td>120000.00</td><td>95000.00</td><td>83.50</td><td>60</td></tr>
            <tr><td>Loja B</td><td>3200.00</td><td>90000.00</td><td>65000.00</td><td>72.00</td><td>44</td></tr>
        </table>
        """

        result = await adapter.sync_all_stores()

        assert result["status"] == "synced"
        assert len(result["stores"]) == 2
        assert result["stores"][0]["store_name"] == "Loja A"
        assert result["stores"][0]["daily_revenue"] == 5000.00


@pytest.mark.asyncio
async def test_sync_all_stores_timeout(adapter):
    with patch("adapter.wingestor_adapter.async_playwright") as mock_pw:
        mock_pw.return_value.start.side_effect = TimeoutError("Timeout ao acessar WinGestor")

        result = await adapter.sync_all_stores()

        assert result["status"] == "error"
        assert "Timeout" in result["error"]
