import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
from main import app

client = TestClient(app)


def test_get_dashboard_success():
    mock_stores = [
        {
            "store_id": "loja-01",
            "store_name": "Loja Teste",
            "daily_revenue": 5000.00,
            "monthly_goal": 120000.00,
            "monthly_revenue": 95000.00,
            "ticket_avg": 83.50,
            "sale_count": 60,
            "last_sync": "2026-05-24T10:00:00",
            "is_below_goal": False,
        }
    ]

    with patch("api.routes.DatabaseManager") as MockDB:
        mock_db = MagicMock()
        MockDB.return_value = mock_db
        mock_db.get_all_stores.return_value = mock_stores
        mock_db.get_last_sync.return_value = "2026-05-24T10:00:00"

        response = client.get("/api/v1/dashboard")

        assert response.status_code == 200
        data = response.json()
        assert len(data["stores"]) == 1
        assert data["stores"][0]["store_name"] == "Loja Teste"
        assert "last_sync" in data


def test_get_dashboard_empty():
    with patch("api.routes.DatabaseManager") as MockDB:
        mock_db = MagicMock()
        MockDB.return_value = mock_db
        mock_db.get_all_stores.return_value = []

        response = client.get("/api/v1/dashboard")

        assert response.status_code == 200
        data = response.json()
        assert len(data["stores"]) == 0


def test_health_endpoint():
    response = client.get("/api/v1/dashboard/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
