const express = require('express');
const { AccessToken } = require('livekit-server-sdk');
const { RoomConfiguration } = require('@livekit/protocol');
const { spawn } = require('child_process');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '.env') });

const app = express();
app.use(express.json());

const LIVEKIT_URL = process.env.LIVEKIT_URL;
const API_KEY = process.env.LIVEKIT_API_KEY;
const API_SECRET = process.env.LIVEKIT_API_SECRET;
const AGENT_DIR = path.resolve(__dirname, '..', 'jarvis-agent');

let agentProcess = null;

function createParticipantToken(userInfo, roomName, agentName) {
  const at = new AccessToken(API_KEY, API_SECRET, {
    ...userInfo,
    ttl: '15m',
  });
  at.addGrant({ room: roomName, roomJoin: true, canPublish: true, canPublishData: true, canSubscribe: true });
  if (agentName) {
    at.roomConfig = new RoomConfiguration({ agents: [{ agentName }] });
  }
  return at.toJwt();
}

app.post('/api/connection-details', async (req, res) => {
  try {
    const body = req.body || {};
    const agentName = body?.room_config?.agents?.[0]?.agent_name;
    const participantName = 'user';
    const participantIdentity = `voice_assistant_user_${Math.floor(Math.random() * 10000)}`;
    const roomName = `voice_assistant_room_${Math.floor(Math.random() * 10000)}`;
    const participantToken = await createParticipantToken(
      { identity: participantIdentity, name: participantName },
      roomName,
      agentName
    );
    res.json({ serverUrl: LIVEKIT_URL, roomName, participantToken, participantName });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/system/livekit/token', async (req, res) => {
  try {
    const room = req.query.room || 'tokio_ia_room';
    const user = req.query.user || 'Admin';
    const identity = `tokyo_${user}_${Math.floor(Math.random() * 10000)}`;
    const token = await createParticipantToken({ identity, name: user }, room, '');
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/system/livekit/agent/status', (req, res) => {
  const running = agentProcess !== null && agentProcess.exitCode === null;
  res.json({ running });
});

app.post('/api/system/livekit/agent/start', (req, res) => {
  if (agentProcess && agentProcess.exitCode === null) {
    return res.json({ status: 'already_running' });
  }
  agentProcess = spawn(
    path.join(AGENT_DIR, 'venv', 'bin', 'python3'),
    [path.join(AGENT_DIR, 'Jarvis- Aula 01', 'agent.py'), 'start'],
    {
      cwd: path.join(AGENT_DIR, 'Jarvis- Aula 01'),
      env: { ...process.env },
      stdio: 'ignore',
    }
  );
  agentProcess.on('exit', () => { agentProcess = null; });
  res.json({ status: 'started' });
});

app.post('/api/system/livekit/agent/stop', (req, res) => {
  if (agentProcess) {
    agentProcess.kill('SIGTERM');
    agentProcess = null;
  }
  res.json({ status: 'stopped' });
});

app.get('/api/system/ai/status', (req, res) => {
  res.json({ success: true, isOnline: false });
});

const PORT = 3002;
app.listen(PORT, () => {
  console.log(`Token server running on http://0.0.0.0:${PORT}`);
});
